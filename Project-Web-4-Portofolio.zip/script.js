// harus pakai button ternyata wkwkwk

function redirInstagram() {
    window.location.href = 
    "https://instagram.com/rfly_rzqllh"
}

function redirWhatsapp() {
    window.location.href = 
    "https://wa.me/+083135852840"
}

const redirGmail = () =>{
    window.location.href = 
    "mailto:rizqullahyusufrafly@gmail.com"
}
